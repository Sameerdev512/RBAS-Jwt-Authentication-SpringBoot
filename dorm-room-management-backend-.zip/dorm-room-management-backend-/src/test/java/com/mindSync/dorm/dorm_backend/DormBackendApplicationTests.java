package com.mindSync.dorm.dorm_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DormBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
