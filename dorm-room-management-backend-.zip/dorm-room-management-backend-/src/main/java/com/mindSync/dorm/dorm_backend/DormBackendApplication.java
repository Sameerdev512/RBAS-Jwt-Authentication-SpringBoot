package com.mindSync.dorm.dorm_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DormBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(DormBackendApplication.class, args);
	}

}
