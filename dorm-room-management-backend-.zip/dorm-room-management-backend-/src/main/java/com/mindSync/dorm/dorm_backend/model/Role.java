package com.mindSync.dorm.dorm_backend.model;

public enum Role {
    USER,
    ADMIN
}
